-- Add cita_cita column to students table
ALTER TABLE public.students 
ADD COLUMN cita_cita TEXT;