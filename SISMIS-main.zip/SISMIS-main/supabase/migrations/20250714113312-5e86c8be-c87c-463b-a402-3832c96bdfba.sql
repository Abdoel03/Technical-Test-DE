
-- Create students table with comprehensive student information
CREATE TABLE public.students (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  nis VARCHAR(20) UNIQUE NOT NULL,
  nama VARCHAR(100) NOT NULL,
  kelas VARCHAR(10) NOT NULL,
  jenis_kelamin VARCHAR(15) NOT NULL CHECK (jenis_kelamin IN ('Laki-laki', 'Perempuan')),
  tempat_lahir VARCHAR(50) NOT NULL,
  tanggal_lahir DATE NOT NULL,
  agama VARCHAR(20) NOT NULL,
  alamat TEXT NOT NULL,
  nama_ayah VARCHAR(100) NOT NULL,
  nama_ibu VARCHAR(100) NOT NULL,
  pekerjaan_ayah VARCHAR(50) NOT NULL,
  pekerjaan_ibu VARCHAR(50) NOT NULL,
  no_telepon_orang_tua VARCHAR(20) NOT NULL,
  email VARCHAR(100),
  status_siswa VARCHAR(15) NOT NULL DEFAULT 'Aktif' CHECK (status_siswa IN ('Aktif', 'Tidak Aktif')),
  tahun_masuk VARCHAR(4) NOT NULL,
  foto_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create index for better query performance
CREATE INDEX idx_students_kelas ON public.students(kelas);
CREATE INDEX idx_students_status ON public.students(status_siswa);
CREATE INDEX idx_students_tahun_masuk ON public.students(tahun_masuk);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_students_updated_at 
    BEFORE UPDATE ON public.students 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- Enable Row Level Security (RLS) for data protection
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;

-- Create policy to allow all operations for authenticated users (admin/teachers)
CREATE POLICY "Allow all operations for authenticated users" 
  ON public.students 
  FOR ALL 
  USING (true) 
  WITH CHECK (true);

-- Insert sample data from existing students data
INSERT INTO public.students (
  nis, nama, kelas, jenis_kelamin, tempat_lahir, tanggal_lahir, agama, alamat,
  nama_ayah, nama_ibu, pekerjaan_ayah, pekerjaan_ibu, no_telepon_orang_tua, 
  email, status_siswa, tahun_masuk
) VALUES 
('2024001', 'Ahmad Fauzi Rahman', '6A', 'Laki-laki', 'Jakarta', '2012-03-15', 'Islam', 
 'Jl. Masjid Raya No. 123, Kelurahan Kebon Jeruk, Jakarta Barat',
 'Budi Rahman', 'Siti Aminah', 'Guru', 'Ibu Rumah Tangga', '0812-3456-7890',
 'ahmad.fauzi@email.com', 'Aktif', '2018'),

('2024002', 'Fatimah Zahra Putri', '5B', 'Perempuan', 'Bandung', '2013-07-22', 'Islam',
 'Jl. Pondok Indah No. 45, Kelurahan Pondok Pinang, Jakarta Selatan',
 'Muhammad Saleh', 'Khadijah Azzahra', 'Wiraswasta', 'Dokter', '0813-2468-1357',
 'fatimah.zahra@email.com', 'Aktif', '2019'),

('2024003', 'Muhammad Rizki Pratama', '4A', 'Laki-laki', 'Surabaya', '2014-11-08', 'Islam',
 'Jl. Al-Hikmah No. 67, Kelurahan Menteng, Jakarta Pusat',
 'Abdul Hakim', 'Nur Halimah', 'Pegawai Negeri', 'Guru', '0814-5678-9012',
 NULL, 'Aktif', '2020'),

('2024004', 'Aisyah Nur Kamila', '3B', 'Perempuan', 'Yogyakarta', '2015-01-30', 'Islam',
 'Jl. Baitul Makmur No. 89, Kelurahan Tebet, Jakarta Selatan',
 'Umar Faruq', 'Maryam Salsabila', 'Insinyur', 'Akuntan', '0815-9876-5432',
 'aisyah.kamila@email.com', 'Aktif', '2021'),

('2024005', 'Yusuf Ibrahim Hakim', '2A', 'Laki-laki', 'Medan', '2016-05-12', 'Islam',
 'Jl. Nurul Iman No. 34, Kelurahan Cempaka Putih, Jakarta Pusat',
 'Ibrahim Hakim', 'Zainab Fatimah', 'Pedagang', 'Bidan', '0816-1234-5678',
 NULL, 'Aktif', '2022'),

('2024006', 'Hafizah Qurrotul Ain', '1B', 'Perempuan', 'Palembang', '2017-09-18', 'Islam',
 'Jl. Hidayatullah No. 56, Kelurahan Kebayoran Baru, Jakarta Selatan',
 'Ali Imran', 'Hafsah Ummu Salamah', 'Ustadz', 'Ustadzah', '0817-8765-4321',
 NULL, 'Aktif', '2023');
