-- Add NISN field to students table
ALTER TABLE public.students 
ADD COLUMN nisn character varying;