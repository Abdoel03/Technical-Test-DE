
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Tables, TablesInsert } from '@/integrations/supabase/types';
import { useToast } from '@/hooks/use-toast';

type Student = Tables<'students'>;
type StudentInsert = TablesInsert<'students'>;

export const useStudents = (kelasFilter?: string) => {
  return useQuery({
    queryKey: ['students', kelasFilter],
    queryFn: async () => {
      let query = supabase
        .from('students')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (kelasFilter) {
        query = query.eq('kelas', kelasFilter);
      }
      
      const { data, error } = await query;
      
      if (error) {
        console.error('Error fetching students:', error);
        throw error;
      }
      
      return data as Student[];
    },
  });
};

export const useAddStudent = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (studentData: StudentInsert) => {
      const { data, error } = await supabase
        .from('students')
        .insert(studentData)
        .select()
        .single();
      
      if (error) {
        console.error('Error adding student:', error);
        throw error;
      }
      
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['students'] });
      toast({
        title: "Berhasil!",
        description: "Data siswa baru telah ditambahkan.",
      });
    },
    onError: (error) => {
      console.error('Add student error:', error);
      toast({
        title: "Error!",
        description: "Gagal menambahkan data siswa. Silakan coba lagi.",
        variant: "destructive",
      });
    },
  });
};

export const useUpdateStudent = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<StudentInsert> }) => {
      const { data: updatedData, error } = await supabase
        .from('students')
        .update(data)
        .eq('id', id)
        .select()
        .single();
      
      if (error) {
        console.error('Error updating student:', error);
        throw error;
      }
      
      return updatedData;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['students'] });
      toast({
        title: "Berhasil!",
        description: "Data siswa telah diperbarui.",
      });
    },
    onError: (error) => {
      console.error('Update student error:', error);
      toast({
        title: "Error!",
        description: "Gagal memperbarui data siswa. Silakan coba lagi.",
        variant: "destructive",
      });
    },
  });
};

export const useDeleteStudent = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('students')
        .delete()
        .eq('id', id);
      
      if (error) {
        console.error('Error deleting student:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['students'] });
      toast({
        title: "Berhasil!",
        description: "Data siswa telah dihapus.",
      });
    },
    onError: (error) => {
      console.error('Delete student error:', error);
      toast({
        title: "Error!",
        description: "Gagal menghapus data siswa. Silakan coba lagi.",
        variant: "destructive",
      });
    },
  });
};
