
import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';

interface ClassFilterProps {
  selectedClass: string;
  onClassChange: (value: string) => void;
  studentCounts: Record<string, number>;
}

const ClassFilter = ({ selectedClass, onClassChange, studentCounts }: ClassFilterProps) => {
  const kelasOptions = [
    { value: 'all', label: 'Semua Kelas' },
    { value: 'Fatimah', label: 'Kelas Fatimah' },
    { value: 'Al Farobi', label: 'Kelas Al Farobi' },
    { value: 'Al Zahrawi', label: 'Kelas Al Zahrawi' },
    { value: 'Al Ghozali', label: 'Kelas Al Ghozali' },
    { value: 'Al Kindi', label: 'Kelas Al Kindi' },
    { value: 'Ibnu Sina', label: 'Kelas Ibnu Sina' },
    { value: 'Hamzah', label: 'Kelas Hamzah' },
    { value: 'Zubair', label: 'Kelas Zubair' },
    { value: 'Umar', label: 'Kelas Umar' },
    { value: 'Zaid', label: 'Kelas Zaid' },
    { value: 'Uwais', label: 'Kelas Uwais' },
    { value: 'Al Khawarizmi', label: 'Kelas Al Khawarizmi' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-4">
        <Select value={selectedClass} onValueChange={onClassChange}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filter berdasarkan kelas" />
          </SelectTrigger>
          <SelectContent>
            {kelasOptions.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
                {option.value !== 'all' && studentCounts[option.value] ? ` (${studentCounts[option.value]})` : ''}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      {/* Class overview cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
        {kelasOptions.slice(1).map((kelas) => (
          <Card 
            key={kelas.value} 
            className={`cursor-pointer transition-colors hover:bg-emerald-50 ${
              selectedClass === kelas.value ? 'bg-emerald-100 border-emerald-300' : ''
            }`}
            onClick={() => onClassChange(kelas.value)}
          >
            <CardContent className="p-3 text-center">
              <div className="text-sm font-medium text-emerald-700">{kelas.value}</div>
              <div className="text-lg font-bold text-emerald-800">
                {studentCounts[kelas.value] || 0}
              </div>
              <div className="text-xs text-gray-500">siswa</div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ClassFilter;
