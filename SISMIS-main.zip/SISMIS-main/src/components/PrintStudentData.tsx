import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Printer } from 'lucide-react';
import { Tables } from '@/integrations/supabase/types';

type Student = Tables<'students'>;

interface PrintStudentDataProps {
  student: Student;
}

const PrintStudentData = ({ student }: PrintStudentDataProps) => {
  const [paperSize, setPaperSize] = useState('A4');

  const paperSizes = {
    A0: { width: '841mm', height: '1189mm' },
    A1: { width: '594mm', height: '841mm' },
    A2: { width: '420mm', height: '594mm' },
    A3: { width: '297mm', height: '420mm' },
    A4: { width: '210mm', height: '297mm' },
    A5: { width: '148mm', height: '210mm' },
    A6: { width: '105mm', height: '148mm' }
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const formatDate = (dateString: string) => {
      const date = new Date(dateString);
      return date.toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      });
    };

    const calculateAge = (dateString: string) => {
      const birthDate = new Date(dateString);
      const today = new Date();
      let age = today.getFullYear() - birthDate.getFullYear();
      const monthDiff = today.getMonth() - birthDate.getMonth();
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      return age;
    };

    const selectedSize = paperSizes[paperSize as keyof typeof paperSizes];

    const printContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Biodata Siswa - ${student.nama}</title>
          <style>
            @page {
              size: ${paperSize};
              margin: 20mm;
            }
            body {
              font-family: Arial, sans-serif;
              line-height: 1.4;
              color: #333;
              margin: 0;
              padding: 0;
              width: 100%;
            }
            .header {
              text-align: center;
              margin-bottom: 20px;
              border-bottom: 3px solid #7c3aed;
              padding-bottom: 15px;
            }
            .school-name {
              font-size: ${paperSize === 'A6' || paperSize === 'A5' ? '18px' : '24px'};
              font-weight: bold;
              color: #7c3aed;
              margin-bottom: 5px;
            }
            .subtitle {
              font-size: ${paperSize === 'A6' || paperSize === 'A5' ? '12px' : '16px'};
              color: #666;
              margin-bottom: 10px;
            }
            .title {
              font-size: ${paperSize === 'A6' || paperSize === 'A5' ? '16px' : '20px'};
              font-weight: bold;
              margin-top: 10px;
            }
            .content-area {
              display: flex;
              gap: 20px;
              margin-bottom: 20px;
            }
            .student-photo {
              width: ${paperSize === 'A6' || paperSize === 'A5' ? '80px' : '120px'};
              height: ${paperSize === 'A6' || paperSize === 'A5' ? '100px' : '150px'};
              border: 2px solid #7c3aed;
              background: #f0f0f0;
              display: flex;
              align-items: center;
              justify-content: center;
              color: #666;
              flex-shrink: 0;
              font-size: ${paperSize === 'A6' || paperSize === 'A5' ? '8px' : '12px'};
            }
            .info-container {
              flex: 1;
            }
            .info-grid {
              display: grid;
              grid-template-columns: ${paperSize === 'A6' ? '1fr' : '1fr 1fr'};
              gap: ${paperSize === 'A6' || paperSize === 'A5' ? '8px' : '12px'};
            }
            .info-item {
              margin-bottom: ${paperSize === 'A6' || paperSize === 'A5' ? '6px' : '8px'};
            }
            .label {
              font-weight: bold;
              color: #7c3aed;
              display: inline-block;
              margin-right: 8px;
              font-size: ${paperSize === 'A6' || paperSize === 'A5' ? '10px' : '12px'};
            }
            .value {
              color: #333;
              font-size: ${paperSize === 'A6' || paperSize === 'A5' ? '10px' : '12px'};
            }
            .section-title {
              color: #7c3aed;
              font-size: ${paperSize === 'A6' || paperSize === 'A5' ? '12px' : '14px'};
              font-weight: bold;
              margin: ${paperSize === 'A6' || paperSize === 'A5' ? '10px' : '15px'} 0 ${paperSize === 'A6' || paperSize === 'A5' ? '8px' : '10px'} 0;
              border-bottom: 1px solid #ddd;
              padding-bottom: 3px;
            }
            .parent-info {
              display: grid;
              grid-template-columns: ${paperSize === 'A6' ? '1fr' : '1fr 1fr'};
              gap: ${paperSize === 'A6' || paperSize === 'A5' ? '10px' : '15px'};
              margin-top: 10px;
            }
            .parent-section h4 {
              color: #7c3aed;
              margin-bottom: ${paperSize === 'A6' || paperSize === 'A5' ? '5px' : '8px'};
              font-size: ${paperSize === 'A6' || paperSize === 'A5' ? '11px' : '13px'};
            }
            .footer {
              margin-top: ${paperSize === 'A6' || paperSize === 'A5' ? '15px' : '25px'};
              text-align: right;
              font-size: ${paperSize === 'A6' || paperSize === 'A5' ? '8px' : '10px'};
            }
            .signature-area {
              margin-top: ${paperSize === 'A6' || paperSize === 'A5' ? '20px' : '30px'};
              display: flex;
              justify-content: space-between;
              flex-wrap: ${paperSize === 'A6' ? 'wrap' : 'nowrap'};
              gap: 10px;
            }
            .signature-box {
              text-align: center;
              flex: 1;
              min-width: ${paperSize === 'A6' ? '100%' : '120px'};
              font-size: ${paperSize === 'A6' || paperSize === 'A5' ? '8px' : '10px'};
            }
            .signature-line {
              border-top: 1px solid #000;
              margin-top: ${paperSize === 'A6' || paperSize === 'A5' ? '30px' : '40px'};
              padding-top: 3px;
            }
            @media print {
              body { 
                margin: 0; 
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
              }
              .no-print { display: none; }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <div style="display: flex; align-items: center; justify-content: flex-start; margin-bottom: 10px;">
              <img src="/lovable-uploads/2723e6e6-7070-495f-9a71-aa9fda490d6a.png" alt="Logo" style="width: 60px; height: 60px; margin-right: 15px; object-fit: contain;">
              <div>
                <div class="school-name">SD AL MUKAROMAH</div>
                <div class="subtitle">Islamic School</div>
              </div>
            </div>
            <div class="title">BIODATA SISWA</div>
          </div>

          <div class="content-area">
            <div class="student-photo">
              ${student.foto_url ? `<img src="${student.foto_url}" alt="Foto Siswa" style="width: 100%; height: 100%; object-fit: cover;">` : 'FOTO SISWA'}
            </div>
            <div class="info-container">
              <div class="section-title">IDENTITAS & INFORMASI PRIBADI</div>
              <div class="info-grid">
                <div class="info-item">
                  <span class="label">NIS:</span>
                  <span class="value">${student.nis}</span>
                </div>
                ${student.nisn ? `
                <div class="info-item">
                  <span class="label">NISN:</span>
                  <span class="value">${student.nisn}</span>
                </div>
                ` : ''}
                <div class="info-item">
                  <span class="label">Nama Lengkap:</span>
                  <span class="value">${student.nama}</span>
                </div>
                <div class="info-item">
                  <span class="label">Kelas:</span>
                  <span class="value">${student.kelas}</span>
                </div>
                <div class="info-item">
                  <span class="label">Jenis Kelamin:</span>
                  <span class="value">${student.jenis_kelamin}</span>
                </div>
                <div class="info-item">
                  <span class="label">Tempat Lahir:</span>
                  <span class="value">${student.tempat_lahir}</span>
                </div>
                <div class="info-item">
                  <span class="label">Tanggal Lahir:</span>
                  <span class="value">${formatDate(student.tanggal_lahir)} (${calculateAge(student.tanggal_lahir)} tahun)</span>
                </div>
                <div class="info-item">
                  <span class="label">Agama:</span>
                  <span class="value">${student.agama}</span>
                </div>
                <div class="info-item">
                  <span class="label">Status:</span>
                  <span class="value">${student.status_siswa}</span>
                </div>
                <div class="info-item">
                  <span class="label">Alamat:</span>
                  <span class="value">${student.alamat}</span>
                </div>
                <div class="info-item">
                  <span class="label">No. Telepon Orang Tua:</span>
                  <span class="value">${student.no_telepon_orang_tua}</span>
                </div>
                ${student.email ? `
                <div class="info-item">
                  <span class="label">Email:</span>
                  <span class="value">${student.email}</span>
                </div>
                ` : ''}
                <div class="info-item">
                  <span class="label">Tahun Masuk:</span>
                  <span class="value">${student.tahun_masuk}</span>
                </div>
                ${student.cita_cita ? `
                <div class="info-item">
                  <span class="label">Cita-cita:</span>
                  <span class="value">${student.cita_cita}</span>
                </div>
                ` : ''}
              </div>
            </div>
          </div>

          <div class="section-title">DATA ORANG TUA</div>
          <div class="parent-info">
            <div class="parent-section">
              <h4>AYAH</h4>
              <div class="info-item">
                <span class="label">Nama:</span>
                <span class="value">${student.nama_ayah}</span>
              </div>
              <div class="info-item">
                <span class="label">Pekerjaan:</span>
                <span class="value">${student.pekerjaan_ayah}</span>
              </div>
            </div>
            <div class="parent-section">
              <h4>IBU</h4>
              <div class="info-item">
                <span class="label">Nama:</span>
                <span class="value">${student.nama_ibu}</span>
              </div>
              <div class="info-item">
                <span class="label">Pekerjaan:</span>
                <span class="value">${student.pekerjaan_ibu}</span>
              </div>
            </div>
          </div>

          <div class="footer">
            <p>Dicetak pada: ${new Date().toLocaleDateString('id-ID', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}</p>
          </div>

          <div class="signature-area">
            <div class="signature-box">
              <div>Orang Tua/Wali</div>
              <div class="signature-line">(...........................)</div>
            </div>
            <div class="signature-box">
              <div>Wali Kelas</div>
              <div class="signature-line">(...........................)</div>
            </div>
            <div class="signature-box">
              <div>Kepala Sekolah</div>
              <div class="signature-line">(...........................)</div>
            </div>
          </div>
        </body>
      </html>
    `;

    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.print();
  };

  return (
    <div className="flex items-center space-x-2">
      <Select value={paperSize} onValueChange={setPaperSize}>
        <SelectTrigger className="w-20 h-8 text-xs">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="A0">A0</SelectItem>
          <SelectItem value="A1">A1</SelectItem>
          <SelectItem value="A2">A2</SelectItem>
          <SelectItem value="A3">A3</SelectItem>
          <SelectItem value="A4">A4</SelectItem>
          <SelectItem value="A5">A5</SelectItem>
          <SelectItem value="A6">A6</SelectItem>
        </SelectContent>
      </Select>
      <Button
        onClick={handlePrint}
        variant="outline"
        className="flex items-center space-x-2 border-purple-200 text-purple-700 hover:bg-purple-50"
      >
        <Printer className="w-4 h-4" />
        <span>Cetak Biodata</span>
      </Button>
    </div>
  );
};

export default PrintStudentData;