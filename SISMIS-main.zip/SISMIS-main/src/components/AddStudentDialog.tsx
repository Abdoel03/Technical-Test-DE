
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus } from 'lucide-react';
import { useAddStudent } from '@/hooks/useStudents';

const AddStudentDialog = () => {
  const [open, setOpen] = useState(false);
  const addStudentMutation = useAddStudent();
  
  const [formData, setFormData] = useState({
    nis: '',
    nisn: '',
    nama: '',
    kelas: '',
    jenis_kelamin: '',
    tempat_lahir: '',
    tanggal_lahir: '',
    agama: '',
    alamat: '',
    nama_ayah: '',
    nama_ibu: '',
    pekerjaan_ayah: '',
    pekerjaan_ibu: '',
    no_telepon_orang_tua: '',
    email: '',
    cita_cita: '',
    status_siswa: 'Aktif',
    tahun_masuk: new Date().getFullYear().toString()
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      await addStudentMutation.mutateAsync(formData);
      setOpen(false);
      // Reset form
      setFormData({
        nis: '',
        nisn: '',
        nama: '',
        kelas: '',
        jenis_kelamin: '',
        tempat_lahir: '',
        tanggal_lahir: '',
        agama: '',
        alamat: '',
        nama_ayah: '',
        nama_ibu: '',
        pekerjaan_ayah: '',
        pekerjaan_ibu: '',
        no_telepon_orang_tua: '',
        email: '',
        cita_cita: '',
        status_siswa: 'Aktif',
        tahun_masuk: new Date().getFullYear().toString()
      });
    } catch (error) {
      console.error('Error submitting form:', error);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const kelasOptions = [
    'Fatimah',
    'Al farobi',
    'Al zahrawi',
    'Al Ghozali',
    'Al kindi',
    'Ibnu Sina',
    'Hamzah',
    'Zubair',
    'Umar',
    'Zaid',
    'Uwais',
    'Al khawarizmi'
  ];

  const statusOptions = [
    'Aktif',
    'Siswa Baru',
    'Tidak Aktif',
    'Alumni'
  ];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center space-x-2">
          <Plus className="w-4 h-4" />
          <span>Tambah Siswa</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Tambah Siswa Baru</DialogTitle>
          <DialogDescription>
            Lengkapi data siswa baru dengan informasi yang akurat.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Data Siswa */}
            <div className="space-y-4">
              <h3 className="font-semibold text-emerald-700 border-b pb-2">Data Siswa</h3>
              
              <div>
                <Label htmlFor="nis">NIS *</Label>
                <Input
                  id="nis"
                  value={formData.nis}
                  onChange={(e) => handleInputChange('nis', e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor="nisn">NISN</Label>
                <Input
                  id="nisn"
                  value={formData.nisn}
                  onChange={(e) => handleInputChange('nisn', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="nama">Nama Lengkap *</Label>
                <Input
                  id="nama"
                  value={formData.nama}
                  onChange={(e) => handleInputChange('nama', e.target.value)}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="kelas">Kelas *</Label>
                <Select value={formData.kelas} onValueChange={(value) => handleInputChange('kelas', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih kelas" />
                  </SelectTrigger>
                  <SelectContent>
                    {kelasOptions.map((kelas) => (
                      <SelectItem key={kelas} value={kelas}>{kelas}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="jenis_kelamin">Jenis Kelamin *</Label>
                <Select value={formData.jenis_kelamin} onValueChange={(value) => handleInputChange('jenis_kelamin', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih jenis kelamin" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Laki-laki">Laki-laki</SelectItem>
                    <SelectItem value="Perempuan">Perempuan</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="tempat_lahir">Tempat Lahir *</Label>
                <Input
                  id="tempat_lahir"
                  value={formData.tempat_lahir}
                  onChange={(e) => handleInputChange('tempat_lahir', e.target.value)}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="tanggal_lahir">Tanggal Lahir *</Label>
                <Input
                  id="tanggal_lahir"
                  type="date"
                  value={formData.tanggal_lahir}
                  onChange={(e) => handleInputChange('tanggal_lahir', e.target.value)}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="agama">Agama *</Label>
                <Input
                  id="agama"
                  value={formData.agama}
                  onChange={(e) => handleInputChange('agama', e.target.value)}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="tahun_masuk">Tahun Masuk *</Label>
                <Input
                  id="tahun_masuk"
                  value={formData.tahun_masuk}
                  onChange={(e) => handleInputChange('tahun_masuk', e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor="status_siswa">Status Siswa *</Label>
                <Select value={formData.status_siswa} onValueChange={(value) => handleInputChange('status_siswa', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih status" />
                  </SelectTrigger>
                  <SelectContent>
                    {statusOptions.map((status) => (
                      <SelectItem key={status} value={status}>{status}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {/* Data Orang Tua */}
            <div className="space-y-4">
              <h3 className="font-semibold text-emerald-700 border-b pb-2">Data Orang Tua</h3>
              
              <div>
                <Label htmlFor="nama_ayah">Nama Ayah *</Label>
                <Input
                  id="nama_ayah"
                  value={formData.nama_ayah}
                  onChange={(e) => handleInputChange('nama_ayah', e.target.value)}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="pekerjaan_ayah">Pekerjaan Ayah *</Label>
                <Input
                  id="pekerjaan_ayah"
                  value={formData.pekerjaan_ayah}
                  onChange={(e) => handleInputChange('pekerjaan_ayah', e.target.value)}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="nama_ibu">Nama Ibu *</Label>
                <Input
                  id="nama_ibu"
                  value={formData.nama_ibu}
                  onChange={(e) => handleInputChange('nama_ibu', e.target.value)}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="pekerjaan_ibu">Pekerjaan Ibu *</Label>
                <Input
                  id="pekerjaan_ibu"
                  value={formData.pekerjaan_ibu}
                  onChange={(e) => handleInputChange('pekerjaan_ibu', e.target.value)}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="no_telepon_orang_tua">No. Telepon Orang Tua *</Label>
                <Input
                  id="no_telepon_orang_tua"
                  value={formData.no_telepon_orang_tua}
                  onChange={(e) => handleInputChange('no_telepon_orang_tua', e.target.value)}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="email">Email Siswa</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="cita_cita">Cita-cita</Label>
                <Textarea
                  id="cita_cita"
                  value={formData.cita_cita}
                  onChange={(e) => handleInputChange('cita_cita', e.target.value)}
                  rows={2}
                />
              </div>
            </div>
          </div>
          
          {/* Alamat */}
          <div>
            <Label htmlFor="alamat">Alamat Lengkap *</Label>
            <Textarea
              id="alamat"
              value={formData.alamat}
              onChange={(e) => handleInputChange('alamat', e.target.value)}
              rows={3}
              required
            />
          </div>
          
          <div className="flex justify-end space-x-2 pt-4">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setOpen(false)}
            >
              Batal
            </Button>
            <Button 
              type="submit" 
              disabled={addStudentMutation.isPending}
            >
              {addStudentMutation.isPending ? 'Menyimpan...' : 'Simpan'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddStudentDialog;
