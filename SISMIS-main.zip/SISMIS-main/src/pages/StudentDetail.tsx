
import React, { useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ArrowLeft, User, Phone, MapPin, Calendar, Users, BookOpen, Mail, Loader2 } from 'lucide-react';
import Navbar from '@/components/Navbar';
import PrintStudentData from '@/components/PrintStudentData';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

const StudentDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    if (!isLoggedIn) {
      navigate('/');
    }
  }, [navigate]);

  const { data: student, isLoading, error } = useQuery({
    queryKey: ['student', id],
    queryFn: async () => {
      if (!id) throw new Error('Student ID is required');
      
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .eq('id', id)
        .single();
      
      if (error) {
        console.error('Error fetching student:', error);
        throw error;
      }
      
      return data;
    },
    enabled: !!id,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-purple-50">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-center h-64">
            <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
            <span className="ml-2 text-gray-600">Memuat data siswa...</span>
          </div>
        </div>
      </div>
    );
  }

  if (error || !student) {
    return (
      <div className="min-h-screen bg-purple-50">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Siswa Tidak Ditemukan</h1>
            <Link to="/dashboard">
              <Button>Kembali ke Dashboard</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  const calculateAge = (dateString: string) => {
    const birthDate = new Date(dateString);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  return (
    <div className="min-h-screen bg-purple-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex justify-between items-start mb-4">
            <Link to="/dashboard">
              <Button variant="outline" className="flex items-center space-x-2 border-purple-200 text-purple-700 hover:bg-purple-50">
                <ArrowLeft className="w-4 h-4" />
                <span>Kembali ke Dashboard</span>
              </Button>
            </Link>
            <PrintStudentData student={student} />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">Biodata Siswa</h1>
          <p className="text-gray-600 mt-2">Informasi lengkap siswa SD Al Mukaromah Islamic School</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Card */}
          <div className="lg:col-span-1">
            <Card className="sticky top-4 border-purple-200">
              <CardHeader className="text-center">
                <div className="w-32 h-32 bg-purple-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <User className="w-16 h-16 text-purple-600" />
                </div>
                <CardTitle className="text-xl">{student.nama}</CardTitle>
                <CardDescription className="space-y-2">
                  <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                    NIS: {student.nis}
                  </Badge>
                  <div className="mt-2">
                    <Badge 
                      variant={student.status_siswa === 'Aktif' ? 'default' : 'secondary'}
                      className={student.status_siswa === 'Aktif' ? 'bg-green-100 text-green-800' : ''}
                    >
                      {student.status_siswa}
                    </Badge>
                  </div>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <BookOpen className="w-5 h-5 text-purple-600" />
                    <div>
                      <p className="font-medium">Kelas</p>
                      <p className="text-sm text-gray-600">{student.kelas}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Calendar className="w-5 h-5 text-purple-600" />
                    <div>
                      <p className="font-medium">Tahun Masuk</p>
                      <p className="text-sm text-gray-600">{student.tahun_masuk}</p>
                    </div>
                  </div>
                  {student.email && (
                    <div className="flex items-center space-x-3">
                      <Mail className="w-5 h-5 text-purple-600" />
                      <div>
                        <p className="font-medium">Email</p>
                        <p className="text-sm text-gray-600">{student.email}</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Student Details - Unified Information */}
          <div className="lg:col-span-2">
            <Card className="border-purple-200">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <User className="w-5 h-5 text-purple-600" />
                  <span>Biodata Lengkap Siswa</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Personal Information */}
                  <div>
                    <label className="text-sm font-medium text-gray-500">Nama Lengkap</label>
                    <p className="font-medium text-gray-900">{student.nama}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">NIS</label>
                    <p className="font-medium text-gray-900 font-mono">{student.nis}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Jenis Kelamin</label>
                    <p className="font-medium text-gray-900">{student.jenis_kelamin}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Agama</label>
                    <p className="font-medium text-gray-900">{student.agama}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Tempat Lahir</label>
                    <p className="font-medium text-gray-900">{student.tempat_lahir}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Tanggal Lahir</label>
                    <p className="font-medium text-gray-900">
                      {formatDate(student.tanggal_lahir)} ({calculateAge(student.tanggal_lahir)} tahun)
                    </p>
                  </div>
                  
                  {/* Cita-cita */}
                  {student.cita_cita && (
                    <div>
                      <label className="text-sm font-medium text-gray-500">Cita-cita</label>
                      <p className="font-medium text-gray-900">{student.cita_cita}</p>
                    </div>
                  )}
                  
                  {/* Address */}
                  <div className="md:col-span-2">
                    <label className="text-sm font-medium text-gray-500">Alamat Lengkap</label>
                    <p className="font-medium text-gray-900">{student.alamat}</p>
                  </div>
                  
                  {/* Parent Information */}
                  <div>
                    <label className="text-sm font-medium text-gray-500">Nama Ayah</label>
                    <p className="font-medium text-gray-900">{student.nama_ayah}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Pekerjaan Ayah</label>
                    <p className="font-medium text-gray-900">{student.pekerjaan_ayah}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Nama Ibu</label>
                    <p className="font-medium text-gray-900">{student.nama_ibu}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Pekerjaan Ibu</label>
                    <p className="font-medium text-gray-900">{student.pekerjaan_ibu}</p>
                  </div>
                  
                  {/* Contact Information */}
                  <div>
                    <label className="text-sm font-medium text-gray-500">No. Telepon Orang Tua</label>
                    <p className="font-medium text-gray-900 font-mono">{student.no_telepon_orang_tua}</p>
                  </div>
                  {student.email && (
                    <div>
                      <label className="text-sm font-medium text-gray-500">Email Siswa</label>
                      <p className="font-medium text-gray-900">{student.email}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDetail;
