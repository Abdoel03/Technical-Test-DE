
import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Eye, Users, BookOpen, GraduationCap, Loader2, Trash2 } from 'lucide-react';
import Navbar from '@/components/Navbar';
import AddStudentDialog from '@/components/AddStudentDialog';
import ClassFilter from '@/components/ClassFilter';
import { useStudents, useDeleteStudent } from '@/hooks/useStudents';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

const Dashboard = () => {
  const navigate = useNavigate();
  const [selectedClass, setSelectedClass] = useState('all');
  
  const { data: students = [], isLoading, error } = useStudents(selectedClass === 'all' ? '' : selectedClass);
  const deleteStudentMutation = useDeleteStudent();

  useEffect(() => {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    if (!isLoggedIn) {
      navigate('/');
    }
  }, [navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-purple-50">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-center h-64">
            <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
            <span className="ml-2 text-gray-600">Memuat data siswa...</span>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-purple-50">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-red-600 mb-4">Error memuat data</h1>
            <p className="text-gray-600">Terjadi kesalahan saat memuat data siswa. Silakan refresh halaman.</p>
          </div>
        </div>
      </div>
    );
  }

  const totalSiswa = students.length;
  const siswaAktif = students.filter(s => s.status_siswa === 'Aktif').length;
  const kelasCount = [...new Set(students.map(s => s.kelas))].length;

  // Count students by class
  const studentCounts = students.reduce((acc, student) => {
    acc[student.kelas] = (acc[student.kelas] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  const handleDeleteStudent = (studentId: string) => {
    deleteStudentMutation.mutate(studentId);
  };

  return (
    <div className="min-h-screen bg-purple-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8 flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-600 mt-2">Selamat datang di Sistem Informasi Siswa SD Al Mukaromah Islamic School</p>
          </div>
          <AddStudentDialog />
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-purple-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Siswa</CardTitle>
              <Users className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-700">{totalSiswa}</div>
              <p className="text-xs text-muted-foreground">siswa terdaftar</p>
            </CardContent>
          </Card>
          
          <Card className="border-purple-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Siswa Aktif</CardTitle>
              <GraduationCap className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-700">{siswaAktif}</div>
              <p className="text-xs text-muted-foreground">siswa aktif</p>
            </CardContent>
          </Card>
          
          <Card className="border-purple-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Kelas</CardTitle>
              <BookOpen className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-700">{kelasCount}</div>
              <p className="text-xs text-muted-foreground">kelas aktif</p>
            </CardContent>
          </Card>
        </div>

        {/* Class Filter */}
        <div className="mb-6">
          <ClassFilter 
            selectedClass={selectedClass}
            onClassChange={setSelectedClass}
            studentCounts={studentCounts}
          />
        </div>

        {/* Students Table */}
        <Card className="border-purple-200">
          <CardHeader>
            <CardTitle>
              Daftar Siswa {selectedClass !== 'all' && `- Kelas ${selectedClass}`}
            </CardTitle>
            <CardDescription>
              {selectedClass !== 'all' 
                ? `Data siswa kelas ${selectedClass} SD Al Mukaromah Islamic School`
                : 'Data lengkap siswa SD Al Mukaromah Islamic School'
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            {students.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500">
                  {selectedClass !== 'all' 
                    ? `Tidak ada siswa di kelas ${selectedClass}`
                    : 'Belum ada data siswa. Silakan tambah siswa baru.'
                  }
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-4 font-medium text-gray-700">NIS</th>
                      <th className="text-left p-4 font-medium text-gray-700">Nama Siswa</th>
                      <th className="text-left p-4 font-medium text-gray-700">Kelas</th>
                      <th className="text-left p-4 font-medium text-gray-700">Jenis Kelamin</th>
                      <th className="text-left p-4 font-medium text-gray-700">Status</th>
                      <th className="text-left p-4 font-medium text-gray-700">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((student) => (
                      <tr key={student.id} className="border-b hover:bg-purple-50">
                        <td className="p-4 font-mono text-sm">{student.nis}</td>
                        <td className="p-4">
                          <div>
                            <div className="font-medium text-gray-900">{student.nama}</div>
                            <div className="text-sm text-gray-500">{student.nama_ayah} & {student.nama_ibu}</div>
                          </div>
                        </td>
                        <td className="p-4">
                          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                            {student.kelas}
                          </Badge>
                        </td>
                        <td className="p-4 text-sm text-gray-600">{student.jenis_kelamin}</td>
                        <td className="p-4">
                          <Badge 
                            variant={student.status_siswa === 'Aktif' ? 'default' : 'secondary'}
                            className={student.status_siswa === 'Aktif' ? 'bg-green-100 text-green-800' : ''}
                          >
                            {student.status_siswa}
                          </Badge>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center space-x-2">
                            <Link to={`/student/${student.id}`}>
                              <Button size="sm" variant="outline" className="flex items-center space-x-1 border-purple-200 text-purple-700 hover:bg-purple-50">
                                <Eye className="w-4 h-4" />
                                <span>Detail</span>
                              </Button>
                            </Link>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button size="sm" variant="outline" className="flex items-center space-x-1 border-red-200 text-red-700 hover:bg-red-50">
                                  <Trash2 className="w-4 h-4" />
                                  <span>Hapus</span>
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Konfirmasi Hapus Data</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Apakah Anda yakin ingin menghapus data siswa <strong>{student.nama}</strong> (NIS: {student.nis})?
                                    <br />
                                    Tindakan ini tidak dapat dibatalkan.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Batal</AlertDialogCancel>
                                  <AlertDialogAction 
                                    onClick={() => handleDeleteStudent(student.id)}
                                    className="bg-red-600 hover:bg-red-700"
                                  >
                                    Hapus Data
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
