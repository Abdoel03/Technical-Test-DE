
export interface Student {
  id: string;
  nis: string;
  nama: string;
  kelas: string;
  jenisKelamin: 'Laki-laki' | 'Perempuan';
  tempatLahir: string;
  tanggalLahir: string;
  agama: string;
  alamat: string;
  namaAyah: string;
  namaIbu: string;
  pekerjaanAyah: string;
  pekerjaanIbu: string;
  noTeleponOrangTua: string;
  email?: string;
  statusSiswa: 'Aktif' | 'Tidak Aktif';
  tahunMasuk: string;
  foto?: string;
}

export const studentsData: Student[] = [
  {
    id: '1',
    nis: '2024001',
    nama: 'Ahmad Fauzi Rahman',
    kelas: 'Fatimah',
    jenisKelamin: 'Laki-laki',
    tempatLahir: 'Jakarta',
    tanggalLahir: '2012-03-15',
    agama: 'Islam',
    alamat: 'Jl. Masjid Raya No. 123, Kelurahan Kebon Jeruk, Jakarta Barat',
    namaAyah: 'Budi Rahman',
    namaIbu: 'Siti Aminah',
    pekerjaanAyah: 'Guru',
    pekerjaanIbu: 'Ibu Rumah Tangga',
    noTeleponOrangTua: '0812-3456-7890',
    email: 'ahmad.fauzi@email.com',
    statusSiswa: 'Aktif',
    tahunMasuk: '2018'
  },
  {
    id: '2',
    nis: '2024002',
    nama: 'Fatimah Zahra Putri',
    kelas: 'Al Farobi',
    jenisKelamin: 'Perempuan',
    tempatLahir: 'Bandung',
    tanggalLahir: '2013-07-22',
    agama: 'Islam',
    alamat: 'Jl. Pondok Indah No. 45, Kelurahan Pondok Pinang, Jakarta Selatan',
    namaAyah: 'Muhammad Saleh',
    namaIbu: 'Khadijah Azzahra',
    pekerjaanAyah: 'Wiraswasta',
    pekerjaanIbu: 'Dokter',
    noTeleponOrangTua: '0813-2468-1357',
    email: 'fatimah.zahra@email.com',
    statusSiswa: 'Aktif',
    tahunMasuk: '2019'
  },
  {
    id: '3',
    nis: '2024003',
    nama: 'Muhammad Rizki Pratama',
    kelas: 'Al Zahrawi',
    jenisKelamin: 'Laki-laki',
    tempatLahir: 'Surabaya',
    tanggalLahir: '2014-11-08',
    agama: 'Islam',
    alamat: 'Jl. Al-Hikmah No. 67, Kelurahan Menteng, Jakarta Pusat',
    namaAyah: 'Abdul Hakim',
    namaIbu: 'Nur Halimah',
    pekerjaanAyah: 'Pegawai Negeri',
    pekerjaanIbu: 'Guru',
    noTeleponOrangTua: '0814-5678-9012',
    statusSiswa: 'Aktif',
    tahunMasuk: '2020'
  },
  {
    id: '4',
    nis: '2024004',
    nama: 'Aisyah Nur Kamila',
    kelas: 'Al Ghozali',
    jenisKelamin: 'Perempuan',
    tempatLahir: 'Yogyakarta',
    tanggalLahir: '2015-01-30',
    agama: 'Islam',
    alamat: 'Jl. Baitul Makmur No. 89, Kelurahan Tebet, Jakarta Selatan',
    namaAyah: 'Umar Faruq',
    namaIbu: 'Maryam Salsabila',
    pekerjaanAyah: 'Insinyur',
    pekerjaanIbu: 'Akuntan',
    noTeleponOrangTua: '0815-9876-5432',
    email: 'aisyah.kamila@email.com',
    statusSiswa: 'Aktif',
    tahunMasuk: '2021'
  },
  {
    id: '5',
    nis: '2024005',
    nama: 'Yusuf Ibrahim Hakim',
    kelas: 'Al Kindi',
    jenisKelamin: 'Laki-laki',
    tempatLahir: 'Medan',
    tanggalLahir: '2016-05-12',
    agama: 'Islam',
    alamat: 'Jl. Nurul Iman No. 34, Kelurahan Cempaka Putih, Jakarta Pusat',
    namaAyah: 'Ibrahim Hakim',
    namaIbu: 'Zainab Fatimah',
    pekerjaanAyah: 'Pedagang',
    pekerjaanIbu: 'Bidan',
    noTeleponOrangTua: '0816-1234-5678',
    statusSiswa: 'Aktif',
    tahunMasuk: '2022'
  },
  {
    id: '6',
    nis: '2024006',
    nama: 'Hafizah Qurrotul Ain',
    kelas: 'Ibnu Sina',
    jenisKelamin: 'Perempuan',
    tempatLahir: 'Palembang',
    tanggalLahir: '2017-09-18',
    agama: 'Islam',
    alamat: 'Jl. Hidayatullah No. 56, Kelurahan Kebayoran Baru, Jakarta Selatan',
    namaAyah: 'Ali Imran',
    namaIbu: 'Hafsah Ummu Salamah',
    pekerjaanAyah: 'Ustadz',
    pekerjaanIbu: 'Ustadzah',
    noTeleponOrangTua: '0817-8765-4321',
    statusSiswa: 'Aktif',
    tahunMasuk: '2023'
  }
];
